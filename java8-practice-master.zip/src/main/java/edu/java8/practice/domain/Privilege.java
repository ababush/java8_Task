package edu.java8.practice.domain;

public enum Privilege {
    CREATE, UPDATE, READ, DELETE;


}