package edu.java8.practice.service.impl;

import edu.java8.practice.domain.Privilege;
import edu.java8.practice.domain.User;
import edu.java8.practice.service.UserService;

import java.util.*;
import java.util.Map.Entry;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static java.util.Arrays.asList;


public class UserServiceImpl implements UserService {

    @Override
    public List<User> sortByAgeDescAndNameAsc(final List<User> users) {

        List<User> listOfUsers = users;
        //First implementation
        Collections.sort(listOfUsers, Comparator.comparing(User::getFirstName));
        Collections.sort(listOfUsers, Comparator.comparingInt(User::getAge).reversed());

        return users;

    }

    @Override
    public List<Privilege> getAllDistinctPrivileges(final List<User> users) {
        List<Privilege> list = users.stream()
                .flatMap(s -> s.getPrivileges().stream())
                .distinct()
                .collect(Collectors.toList());

        return list;
    }

    @Override
    public Optional<User> getUpdateUserWithAgeHigherThan(final List<User> users, final int age) {

        User result1 = users.stream()
                .filter(u -> u.getAge() > age && u.getPrivileges().equals(asList(Privilege.UPDATE)))
                .findAny()
                .orElse(null);

        Optional<User> optUser1 = Optional.of(result1);

        return optUser1;

    }

    @Override
    public Map<Integer, List<User>> groupByCountOfPrivileges(final List<User> users) {
        Map<Integer, List<User>> result = users.stream().collect(Collectors.groupingBy(s -> s.getPrivileges().size()));

        return result;
    }

    @Override
    public double getAverageAgeForUsers(final List<User> users) {
        return users.stream()
                .mapToDouble(User::getAge)
                .average()
                .orElse(-1);
    }

    @Override
    public Optional<String> getMostFrequentLastName(final List<User> users) {

        String maxVal = users.stream()
                .collect(Collectors.groupingBy(User::getLastName, Collectors.counting()))
                .entrySet().stream()
                .max(Comparator.comparing(Entry::getValue))
                .filter((n) -> n.getValue() != 1)
                .map(Entry::getKey).orElse(null);


        return Optional.ofNullable(maxVal);
    }

    @Override
    public List<User> filterBy(final List<User> users, final Predicate<User>... predicates) {
        Predicate<User> allPredicates = x -> Arrays.stream(predicates)
                .mapToInt(predicate -> !predicate.test(x) ? 1 : 0).sum() == 0;

        return users.stream().filter(allPredicates).collect(Collectors.toList());
    }

    @Override
    public String convertTo(final List<User> users, final String delimiter, final Function<User, String> mapFun) {
        return users.stream()
                .map(s -> s.getLastName())
                .collect(Collectors.joining(delimiter));
    }



    @Override
    public Map<Privilege, List<User>> groupByPrivileges(List<User> users) {


//        return  users.stream()
//                        .collect(
//                                 Collectors.flatMapping(u -> u.getPrivileges().stream(),
//                                        Collectors.toMap(Function.identity(),
//                                                privilege -> users.stream().filter(user -> user.getPrivileges().contains(privilege)).collect(Collectors.toList()),
//                                                (left, right) -> {left.addAll(right); return left;})));

        return null;


    }



    @Override
    public Map<String, Long> getNumberOfLastNames(final List<User> users) {

        return users.stream()
                .collect(Collectors.groupingBy(User::getLastName, Collectors.counting()));
    }

    public static void main(String[] args) {
//        UserServiceImpl uImp = new UserServiceImpl();
//        final User user1 = new User(1L, "John", "Doe", 26, singletonList(Privilege.UPDATE));
//        final User user2 = new User(2L, "Greg", "Jonson", 30, asList(Privilege.UPDATE, Privilege.CREATE, Privilege.DELETE));
//        final User user3 = new User(3L, "Alex", "Smith", 13, singletonList(Privilege.DELETE));
//
//        final Map<Privilege, List<User>> groupedMap = uImp.groupByPrivileges(asList(user1, user2, user3));
//
//        groupedMap.forEach((k, v) -> System.out.println(k + " : " + v));
    }
}
